//Numpy array shape [16]
//Min -0.060159195215
//Max 0.046103578061
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
model_default_t b8[16];
#else
model_default_t b8[16] = {0.041289, -0.024371, 0.013293, -0.026666, -0.009135, -0.060159, 0.018055, 0.046104, -0.023486, -0.003924, -0.055770, 0.005678, 0.045038, 0.010098, 0.024645, 0.016457};
#endif

#endif
