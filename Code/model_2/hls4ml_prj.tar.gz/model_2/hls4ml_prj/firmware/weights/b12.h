//Numpy array shape [1]
//Min -0.032276216894
//Max -0.032276216894
//Number of zeros 0

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
model_default_t b12[1];
#else
model_default_t b12[1] = {-0.032276};
#endif

#endif
