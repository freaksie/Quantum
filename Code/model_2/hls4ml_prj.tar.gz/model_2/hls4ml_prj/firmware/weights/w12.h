//Numpy array shape [4, 1]
//Min -0.372263908386
//Max 0.151476234198
//Number of zeros 0

#ifndef W12_H_
#define W12_H_

#ifndef __SYNTHESIS__
model_default_t w12[4];
#else
model_default_t w12[4] = {-0.372264, -0.305988, -0.336824, 0.151476};
#endif

#endif
