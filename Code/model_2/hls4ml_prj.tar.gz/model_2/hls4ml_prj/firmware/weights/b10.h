//Numpy array shape [4]
//Min -0.153333067894
//Max 0.116813078523
//Number of zeros 0

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
model_default_t b10[4];
#else
model_default_t b10[4] = {0.115967, 0.116813, 0.081875, -0.153333};
#endif

#endif
